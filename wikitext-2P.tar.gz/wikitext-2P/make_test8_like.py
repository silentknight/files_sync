#!/usr/bin/env python
import re
import num2words

filename = 'valid'
f = open(filename,'r')
lines = f.readlines()
f.close()

newData = ""

try:
	for line in lines:

		line = line.strip()
		line = line.lower()
		line = re.sub('[^a-zA-Z0-9 \n \. \- \\ \/ \* \' \# \$ \&]', ' ', line)
		line = line.replace(" unk ", " <unk> ")		
		line = re.sub(r"(\d+ )", "N", line)
		line = " ".join(line.split())+"\n"

		newData += line

	f = open("text8"+filename,'w')
	f.write(newData)
	f.close()	
except KeyboardInterrupt:
	print("Done")
